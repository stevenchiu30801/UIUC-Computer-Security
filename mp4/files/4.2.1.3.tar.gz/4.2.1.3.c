#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include <openssl/md5.h>

#define RAND_STR_SIZE 20

char *randstring(char *randstr) {
    static char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    int charset_size = sizeof(charset);
    /* srand(time(NULL)); */
    for (int n = 0; n < RAND_STR_SIZE; n++) {            
        int key = rand() % (charset_size - 1);
        randstr[n] = charset[key];
    }
    randstr[RAND_STR_SIZE] = '\0';
    return randstr;
}

void print_md5_sum(unsigned char* md) {
    int i;
    for(i=0; i < MD5_DIGEST_LENGTH; i++) {
            printf("%02x",md[i]);
    }
}

int match_string(unsigned char * str){
    int i, j, k;
    /* for(i = 0; i < MD5_DIGEST_LENGTH; i++) */
        /* printf("%c", str[i]); */
    for(i = 0; i < MD5_DIGEST_LENGTH - 4; i++){
        if(strncmp(str + i, "'or'", 4) == 0 && str[i + 4] > 48 && str[i + 4] < 58)
            return 1;
        else if(strncmp(str + i, "'oR'", 4) == 0 && str[i + 4] > 48 && str[i + 4] < 58)
            return 1;
        else if(strncmp(str + i, "'Or'", 4) == 0 && str[i + 4] > 48 && str[i + 4] < 58)
            return 1;
        else if(strncmp(str + i, "'OR'", 4) == 0 && str[i + 4] > 48 && str[i + 4] < 58)
            return 1;
        else if(strncmp(str + i, "'||'", 4) == 0 && str[i + 4] > 48 && str[i + 4] < 58)
            return 1;
    }

    return 0;
}

int main(){
    unsigned char result[MD5_DIGEST_LENGTH];
    unsigned char randstr[RAND_STR_SIZE + 1];
    int cnt = 0;
    while(1){
        randstring(randstr);

        MD5(randstr, RAND_STR_SIZE, result);
        /* printf("%s\n", randstr); */
        /* print_md5_sum(result); */
        /* printf("\n"); */
        if(match_string(result) == 1){
            printf("Found: %s\n", randstr);
            break;
        }
        /* if(++cnt % 10000000 == 0) */
        /*     printf("%d\n", cnt); */
    }    

    /* char string[] = "129581926211651571912466741651878684928"; */
    /* MD5((unsigned char*)string, strlen(string), result); */
    /* print_md5_sum(result); */
    /* printf("\n"); */
    /* if(match_string(result) == 1) */
    /*     printf("Found!\n"); */
    /* else */
    /*     printf("Not Found!\n"); */

    return 0;
}
